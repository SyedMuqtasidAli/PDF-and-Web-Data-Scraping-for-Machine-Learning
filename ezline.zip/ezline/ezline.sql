-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2024 at 07:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ezline`
--

-- --------------------------------------------------------

--
-- Table structure for table `dynamic_table`
--

CREATE TABLE `dynamic_table` (
  `unnamed__0` varchar(255) DEFAULT NULL,
  `0` varchar(255) DEFAULT NULL,
  `1` varchar(255) DEFAULT NULL,
  `2` varchar(255) DEFAULT NULL,
  `3` varchar(255) DEFAULT NULL,
  `4` varchar(255) DEFAULT NULL,
  `5` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pdf_data_table`
--

CREATE TABLE `pdf_data_table` (
  `unnamed__0` varchar(255) DEFAULT NULL,
  `0` varchar(255) DEFAULT NULL,
  `1` varchar(255) DEFAULT NULL,
  `2` varchar(255) DEFAULT NULL,
  `3` varchar(255) DEFAULT NULL,
  `4` varchar(255) DEFAULT NULL,
  `5` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pdf_data_table`
--

INSERT INTO `pdf_data_table` (`unnamed__0`, `0`, `1`, `2`, `3`, `4`, `5`) VALUES
('0', NULL, NULL, NULL, NULL, NULL, 'Results'),
('1', NULL, NULL, NULL, 'Ballots', NULL, NULL),
('2', 'Disability', NULL, 'Ballots', NULL, NULL, NULL),
('3', NULL, 'Participants', NULL, 'Incomplete/', NULL, NULL),
('4', 'Category', NULL, 'Completed', NULL, 'Accuracy', 'Time to'),
('5', NULL, NULL, NULL, 'Terminated', NULL, NULL),
('6', NULL, NULL, NULL, NULL, NULL, 'complete'),
('7', 'Blind', '5', '1', '4', '34.5%, n=1', '1199 sec, n=1'),
('8', 'Low Vision', '5', '2', '3', '98.3% n=2', '1716 sec, n=3'),
('9', NULL, NULL, NULL, NULL, '(97.7%, n=3)', '(1934 sec, n=2)'),
('10', 'Dexterity', '5', '4', '1', '98.3%, n=4', '1672.1 sec, n=4'),
('11', 'Mobility', '3', '3', '0', '95.4%, n=3', '1416 sec, n=3');

-- --------------------------------------------------------

--
-- Table structure for table `web_data_table`
--

CREATE TABLE `web_data_table` (
  `unnamed__0` varchar(255) DEFAULT NULL,
  `appliance` varchar(255) DEFAULT NULL,
  `minimum` varchar(255) DEFAULT NULL,
  `maximum` varchar(255) DEFAULT NULL,
  `standby` varchar(255) DEFAULT NULL,
  `other_name(s)` varchar(255) DEFAULT NULL,
  `references` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `web_data_table`
--

INSERT INTO `web_data_table` (`unnamed__0`, `appliance`, `minimum`, `maximum`, `standby`, `other_name(s)`, `references`, `notes`) VALUES
('0', '100W light bulb (Incandescent)', '100W', '100W', '0W', NULL, '[1]', NULL),
('1', '22 Inch LED TV', '17W', '17W', '0.5W', NULL, NULL, NULL),
('2', '25\" colour TV', '150W', '150W', NULL, NULL, NULL, NULL),
('3', '3\" belt sander', '1000W', '1000W', NULL, NULL, NULL, NULL),
('4', '32 Inch LED TV', '20W', '60W', '1W', NULL, NULL, NULL),
('5', '42 Inch LED TV', '58W', '60W', '0.3W', NULL, '[1]', NULL),
('6', '42 Inch Plasma TV', '450W', '600W', NULL, 'Plasma TV', NULL, NULL),
('7', '46 Inch LED TV', '60W', '70W', '1W', NULL, '[1]', NULL),
('8', '49 Inch LED TV', '85W', '85W', '1W', NULL, NULL, NULL),
('9', '55 Inch LED TV', '116W', '116W', '0.5W', NULL, '[1]', NULL),
('10', '60W light bulb (Incandescent)', '60W', '60W', '0W', NULL, '[1]', NULL),
('11', '65 Inch LED TV', '120W', '130W', '1W', NULL, '[1]', NULL),
('12', '82 Inch LED TV', '228W', '295W', '0.5W', NULL, '[1]', NULL),
('13', '9\" disc sander', '1200W', '1200W', NULL, NULL, NULL, NULL),
('14', 'Air Cooler', '65W', '80W', NULL, NULL, NULL, NULL),
('15', 'Air Fryer', '1500W', '1500W', NULL, NULL, '[1]', NULL),
('16', 'Air Purifier', '25W', '30W', NULL, NULL, '[1]', NULL),
('17', 'Amazon Echo', '3W', '3W', '2W', NULL, NULL, NULL),
('18', 'Amazon Echo Dot', '2W', '3W', NULL, NULL, NULL, NULL),
('19', 'Amazon Echo Show', '2W', '4W', '0.1W', NULL, NULL, NULL),
('20', 'American-Style Fridge Freezer', '40W', '80W', NULL, 'American Fridge Freezer,Double Door Refrigerator', '[1]', NULL),
('21', 'Apple TV', '3W', '6W', '0.3W', NULL, '[1]', NULL),
('22', 'Aquarium Pump', '20W', '50W', NULL, NULL, '[1]', NULL),
('23', 'AV Receiver', '450W', '450W', NULL, NULL, '[1]', NULL),
('24', 'Bathroom Towel Heater', '60W', '150W', NULL, 'Towel Rail,Heated Towel Rail', NULL, NULL),
('25', 'Ceiling Fan', '60W', '70W', '0W', NULL, '[1]', NULL),
('26', 'Chromebook', '45W', '45W', NULL, 'Chrome Book', '[1]', NULL),
('27', 'Chromecast', '2W', '2W', NULL, NULL, NULL, NULL),
('28', 'Clock radio', '1W', '2W', NULL, NULL, NULL, NULL),
('29', 'Clothes Dryer', '1000W', '4000W', NULL, 'Tumble Dryer,Dryer', NULL, NULL),
('30', 'Coffee Maker', '800W', '1400W', NULL, NULL, NULL, NULL),
('31', 'Computer Monitor', '25W', '30W', NULL, NULL, '[1]', NULL),
('32', 'Cooker Hood', '20W', '30W', '0W', NULL, '[1]', NULL),
('33', 'Corded Drill', '600W', '850W', NULL, 'Electric Drill', '[1]', NULL),
('34', 'Corded Electric Handheld Leaf Blower', '2500W', '2500W', NULL, NULL, '[1]', NULL),
('35', 'Cordless Drill Charger', '70W', '150W', NULL, NULL, NULL, NULL),
('36', 'Cpap machine', '30W', '60W', NULL, 'CPAP machine', NULL, NULL),
('37', 'Curling Iron', '25W', '35W', '0W', NULL, '[1]', NULL),
('38', 'DAB Mains Radio', '5W', '9W', NULL, 'DAB Radio', NULL, NULL),
('39', 'Deep Freezer', '19W', '19W', NULL, 'Chest Freezer', '[1]', '168 Kwh/year'),
('40', 'Dehumidifier', '240W', '240W', NULL, NULL, '[1]', NULL),
('41', 'Desk Lamp', '40W', '65W', NULL, 'Table Lamp', NULL, NULL),
('42', 'Desktop Computer', '100W', '450W', NULL, NULL, '[1]', NULL),
('43', 'Dishwasher', '1200W', '1500W', NULL, NULL, NULL, NULL),
('44', 'Domestic Water Pump', '200W', '300W', '0W', 'Shower Water Pump', '[1]', NULL),
('45', 'DVD Player', '26W', '60W', NULL, NULL, NULL, NULL),
('46', 'Electric Blanket', '200W', '200W', NULL, NULL, NULL, NULL),
('47', 'Electric Boiler', '4000W', '14000W', NULL, NULL, NULL, NULL),
('48', 'Electric Doorbell Transformer', '2W', '2W', NULL, NULL, NULL, NULL),
('49', 'Electric Heater Fan', '2000W', '3000W', NULL, NULL, '[1]', NULL),
('50', 'Electric Kettle', '1200W', '3000W', '0W', 'Kettle', NULL, NULL),
('51', 'Electric Mower', '1500W', '1500W', NULL, NULL, NULL, NULL),
('52', 'Electric Pressure Cooker', '1000W', '1000W', NULL, 'Pressure Cooker', '[1]', NULL),
('53', 'Electric Shaver', '15W', '20W', NULL, NULL, NULL, NULL),
('54', 'Electric stove', '2000W', '2000W', NULL, NULL, '[1]', NULL),
('55', 'Electric Tankless Water Heater', '6600W', '8800W', NULL, 'Electric Water Heater', '[1]', NULL),
('56', 'Electric Thermal Radiator', '500W', '500W', NULL, 'Thermal Radiator', '[1]', NULL),
('57', 'Electric Toothbrush Charger', '6W', '6W', NULL, NULL, NULL, NULL),
('58', 'Espresso Coffee Machine', '1300W', '1500W', NULL, 'Espresso Machine', NULL, NULL),
('59', 'EV Car Charger', '2000W', '7000W', NULL, NULL, NULL, NULL),
('60', 'EV Home Charger', '1600W', '3400W', NULL, NULL, NULL, NULL),
('61', 'Evaporative Air Conditioner', '2600W', '2600W', NULL, 'Evaporative Cooler', '[1]', NULL),
('62', 'External Hard Drive', '1W', '3W', NULL, NULL, NULL, NULL),
('63', 'Extractor Fan', '12W', '12W', NULL, 'Bathroom Fan', '[1]', NULL),
('64', 'Fluorescent Lamp', '28W', '45W', NULL, 'Fluorescent Tube Light', '[1]', NULL),
('65', 'Food Blender', '300W', '400W', NULL, 'Mixer,Food Processor,Blender,Juice Blender,Juice Mixer', '[1]', NULL),
('66', 'Food Dehydrator', '800W', '800W', NULL, 'Tray Dehydrator', '[1]', NULL),
('67', 'Freezer', '30W', '50W', NULL, NULL, NULL, NULL),
('68', 'Fridge', '100W', '220W', NULL, NULL, NULL, NULL),
('69', 'Fridge / Freezer', '150W', '400W', NULL, NULL, NULL, NULL),
('70', 'Fryer', '1000W', '1000W', NULL, 'Deep Fat Fryer,Deep Fryer', '[1]', NULL),
('71', 'Game Console', '120W', '200W', NULL, NULL, '[1]', NULL),
('72', 'Gaming PC', '300W', '600W', '1W', 'Gaming Computer', NULL, NULL),
('73', 'Garage Door Opener', '300W', '400W', NULL, 'Electric Garage Door', NULL, 'As the door only operates for a short time (10secs?) the kWH value is low'),
('74', 'Google Home Mini', '15W', '15W', '2W', 'Google Nest Mini', '[1]', NULL),
('75', 'Guitar Amplifier', '20W', '30W', NULL, NULL, NULL, NULL),
('76', 'Hair Blow Dryer', '1800W', '2500W', NULL, 'Blow Dryer, Hair Dryer, Hair Drier', NULL, NULL),
('77', 'Hand Wash Oversink Water Heater', '3000W', '3000W', NULL, NULL, '[1]', NULL),
('78', 'Heated Bathroom Mirror', '50W', '100W', NULL, NULL, NULL, NULL),
('79', 'Heated Hair Rollers', '400W', '400W', NULL, 'Heated Rollers', '[1]', NULL),
('80', 'Home Air Conditioner', '1000W', '4000W', NULL, 'AC,A/C,Air Con', NULL, NULL),
('81', 'Home Internet Router', '5W', '15W', NULL, 'Router', NULL, NULL),
('82', 'Home Phone', '3W', '5W', '2W', 'DECT Telephone', NULL, NULL),
('83', 'Home Sound System', '95W', '95W', '1W', NULL, '[1]', NULL),
('84', 'Hot Water Dispenser', '1200W', '1300W', NULL, 'Instant Hot Water Tap,Water Boiler', '[1]', NULL),
('85', 'Hot Water Immersion Heater', '3000W', '3000W', NULL, NULL, NULL, NULL),
('86', 'Humidifier', '35W', '40W', NULL, NULL, '[1]', NULL),
('87', 'iMac', '60W', '240W', '1W', NULL, NULL, NULL),
('88', 'Induction Hob (per hob)', '1400W', '1800W', NULL, 'Induction Stove,Induction Cooking Stove,Electric Cooker,Induction Cooktop', NULL, NULL),
('89', 'Inkjet Printer', '20W', '30W', NULL, 'Printer', NULL, NULL),
('90', 'Inverter Air conditioner', '1300W', '1800W', NULL, NULL, NULL, NULL),
('91', 'Iron', '1000W', '1000W', NULL, 'Electric Iron', NULL, NULL),
('92', 'Jacuzzi', '3000W', '7500W', '1500W', 'Hot Tub', NULL, NULL),
('93', 'Kitchen Extractor Fan', '200W', '200W', NULL, NULL, '[1]', NULL),
('94', 'Laptop Computer', '50W', '100W', NULL, 'Laptop', NULL, NULL),
('95', 'Laser Printer', '600W', '800W', NULL, NULL, NULL, NULL),
('96', 'Lawnmower', '1000W', '1400W', NULL, NULL, NULL, NULL),
('97', 'LED Christmas Lights', '5W', '5W', NULL, 'Tree Lights', NULL, NULL),
('98', 'LED Light Bulb', '7W', '10W', '0W', 'Energy Saver Bulb', '[1][2]', NULL),
('99', 'LG Soundbar', '23W', '30W', '0.5W', 'Soundbar', NULL, NULL),
('100', 'Mi Box', '5W', '7W', '3W', 'Mi Box Android', NULL, NULL),
('101', 'Microwave', '600W', '1700W', '3W', 'Microwave Oven', '[1][2]', NULL),
('102', 'Night Light', '1W', '1W', '0W', NULL, NULL, NULL),
('103', 'Nintendo Switch AC Adapter', '7W', '40W', NULL, NULL, NULL, NULL),
('104', 'Outdoor Hot Tub', '60W', '500W', NULL, 'Canadian Spa,Outdoor spa', '[1]', NULL),
('105', 'Oven', '2150W', '2150W', NULL, 'Electric Oven', NULL, NULL),
('106', 'Paper Shredder', '200W', '220W', NULL, NULL, NULL, NULL),
('107', 'Pedestal Fan', '50W', '60W', NULL, 'Tall Standing Fan,Floor Fan,Stand Fan', NULL, NULL),
('108', 'Percolator', '800W', '1100W', NULL, 'Coffee Maker', '[1]', NULL),
('109', 'Philips Hue Smart Bulb', '8W', '9W', '0.4W', 'Hue lights', NULL, NULL),
('110', 'Phone Charger', '4W', '7W', NULL, 'Smart Phone Charger,Cell Phone Charger,Mobile Phone Charger', NULL, NULL),
('111', 'Playstation 4', '85W', '90W', NULL, 'PS4', NULL, NULL),
('112', 'Playstation 5', '160W', '200W', NULL, 'PS5', NULL, NULL),
('113', 'Portable Air Conditioner', '1000W', '1200W', NULL, 'Mobile Air Conditioner', NULL, NULL),
('114', 'Power Shower', '7500W', '10500W', '0W', 'Electric Shower', '[1]', NULL),
('115', 'Pressure Cooker', '700W', '700W', NULL, NULL, '[1]', NULL),
('116', 'Pressure Washer', '1500W', '1500W', NULL, 'Electric Pressure Washer', NULL, NULL),
('117', 'Projector', '220W', '270W', '1W', NULL, NULL, NULL),
('118', 'Refrigerator', '100W', '200W', NULL, NULL, NULL, NULL),
('119', 'Rice Cooker', '200W', '800W', NULL, NULL, '[1]', NULL),
('120', 'Ring Spotlight Cam Wired', '25W', '4W', '2W', NULL, NULL, NULL),
('121', 'Sandwich Maker', '700W', '1000W', NULL, 'Sandwich Press, Sandwich Toaster', NULL, NULL),
('122', 'Scanner', '10W', '18W', NULL, NULL, NULL, NULL),
('123', 'Set Top Box', '27W', '30W', NULL, 'Cable Box,Humax Box', NULL, NULL),
('124', 'Sewing Machine', '70W', '80W', NULL, NULL, '[1]', NULL),
('125', 'Singer Sewing Machine', '100W', '100W', NULL, NULL, NULL, NULL),
('126', 'Sky Q 2TB Box', '40W', '40W', NULL, 'Sky Box', '[1]', NULL),
('127', 'Slow Cooker', '160W', '180W', NULL, NULL, '[1]', NULL),
('128', 'Smoke Detector', '0W', '1W', NULL, 'Mains Connected Smoke Detector', NULL, NULL),
('129', 'Soldering Iron', '30W', '60W', NULL, NULL, NULL, NULL),
('130', 'Space Heater', '2000W', '5000W', NULL, NULL, '[1]', NULL),
('131', 'Steam Iron', '2200W', '2500W', NULL, NULL, '[1]', NULL),
('132', 'Steriliser', '650W', '650W', NULL, 'Sterilizer', '[1]', NULL),
('133', 'Straightening Iron', '75W', '300W', NULL, 'Hair Straighteners', NULL, NULL),
('134', 'Strimmer', '300W', '500W', NULL, NULL, NULL, NULL),
('135', 'Submersible Water Pump', '200W', '400W', NULL, 'Pool Pump,Sump Pump,Well Pump', '[1]', NULL),
('136', 'Table Fan', '10W', '25W', NULL, 'Desk Fan', NULL, NULL),
('137', 'Table Top Fridge', '10W', '15W', NULL, 'Mini Fridge', NULL, NULL),
('138', 'Tablet Charger', '10W', '15W', NULL, NULL, NULL, NULL),
('139', 'Tablet Computer', '5W', '10W', NULL, NULL, '[1]', NULL),
('140', 'Toaster', '800W', '1800W', '0W', NULL, '[1]', NULL),
('141', 'Tower Fan', '60W', '60W', NULL, NULL, '[1]', NULL),
('142', 'Treadmill', '280W', '900W', NULL, NULL, NULL, NULL),
('143', 'Tube Light (1500mm)', '22W', '22W', NULL, NULL, NULL, NULL),
('144', 'TV (19\" colour)', '40W', '100W', '1W', NULL, '[1]', NULL),
('145', 'Vacuum Cleaner', '450W', '900W', '0W', NULL, '[1][2]', NULL),
('146', 'Wall Fan', '45W', '60W', '0W', NULL, NULL, NULL),
('147', 'Washing Machine', '500W', '500W', '1W', 'Clothes Washer', NULL, 'In the EU, power consumption of Washing Machines is typically given in the form of Annual Power Consumption. This is calculated based on 220 standard washing cycles, made up as follows: 60°C full load (3x), 60°C half load (2x), 40°C half load (2x) for 220'),
('148', 'Water Dispenser', '100W', '100W', NULL, NULL, '[1]', NULL),
('149', 'Water Feature', '35W', '35W', NULL, NULL, NULL, NULL),
('150', 'Water Filter and Cooler', '70W', '100W', NULL, 'Water Cooler', '[1]', NULL),
('151', 'WiFi Booster', '1W', '2W', NULL, 'WiFi Repeater,WiFi Extender,Range Extender', NULL, NULL),
('152', 'WiFi Router', '4W', '10W', '4W', 'Router', NULL, NULL),
('153', 'Window Air Conditioner', '500W', '1500W', NULL, 'Window AC', NULL, NULL),
('154', 'Wine cooler (18 bottles)', '83W', '83W', '0W', NULL, '[1]', NULL),
('155', 'Xbox One', '50W', '110W', '14W', NULL, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
